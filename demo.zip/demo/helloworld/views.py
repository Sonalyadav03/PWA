from django.shortcuts import render
from . import print_name
# Create your views here.

def test(request):
	if request.method == 'POST':
		name = request.POST.get('name')
		s = print_name.print_name(name)
		return render(request,'helloworld/test.html',{'s':s})

	return render(request,'helloworld/test.html')