def print_name(name):
	return ('Hello '+name)
